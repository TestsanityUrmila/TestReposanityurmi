package realtimeengine

type Location struct {
	Line       int `json:"Line"`
	StartIndex int `json:"StartIndex"`
	EndIndex   int `json:"EndIndex"`
}
