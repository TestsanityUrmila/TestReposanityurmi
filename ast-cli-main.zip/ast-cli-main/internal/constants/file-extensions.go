package constants

const (
	ZipExtension   = ".zip"
	SarifExtension = ".sarif"
)
