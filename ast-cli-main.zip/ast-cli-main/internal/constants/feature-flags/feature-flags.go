package featureflags

const (
	AccessManagementEnabled = "ACCESS_MANAGEMENT_ENABLED"
	GroupValidationEnabled  = "GROUPS_VALIDATION_ENABLED"
)
