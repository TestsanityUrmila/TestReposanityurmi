docker rm -f squid
