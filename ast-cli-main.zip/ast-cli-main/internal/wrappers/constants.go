package wrappers

const (
	limitValue    = "10000"
	retryAttempts = 4
	retryDelay    = 500
)
